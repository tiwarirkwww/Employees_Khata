export class Employee {
    id: number= 1;
    firstName: string= " ";
    lastName: string= " ";
    emailId: string=" " ;
}